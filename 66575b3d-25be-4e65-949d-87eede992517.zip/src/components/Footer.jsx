const equipo = [
  { nombre: "Martina López", rol: "CEO & Fundadora", inicial: "ML" },
  { nombre: "Julián Pérez", rol: "Líder Técnico Odoo", inicial: "JP" },
  { nombre: "Camila Restrepo", rol: "Talent Manager", inicial: "CR" },
];

export default function Footer() {
  return (
    <footer className="footer">
      <div className="container footer-grid">
        <div>
          <p className="logo">BOSS<span>-IT</span></p>
          <p className="muted">Staffing IT, partner de Odoo y consultoría en transformación digital desde 2018.</p>
          <p className="muted">Buenos Aires (AR) · Medellín (CO)</p>
          <p className="muted">+54 11 2463-6859</p>
        </div>
        <div>
          <h4 className="footer-title">Nuestro equipo</h4>
          <div className="team">
            {equipo.map((p) => (
              <div key={p.nombre} className="team-card">
                <div className="avatar">{p.inicial}</div>
                <div>
                  <p className="team-name">{p.nombre}</p>
                  <p className="muted small">{p.rol}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
      <p className="container copy">© {new Date().getFullYear()} BOSS-IT · Proyecto de pre-entrega</p>
    </footer>
  );
}
