import { Link } from "@tanstack/react-router";

export default function Item({ id, nombre, categoria, precio, unidad, icono }) {
  return (
    <article className="card">
      <div className="card-icon">{icono}</div>
      <span className="tag">{categoria}</span>
      <h3 className="card-title">{nombre}</h3>
      <p className="price">USD {precio.toLocaleString("es-AR")} <span className="muted small">/ {unidad}</span></p>
      <Link to="/producto/$id" params={{ id: String(id) }} className="btn btn-outline">Ver detalle</Link>
    </article>
  );
}
