import { Link } from "@tanstack/react-router";
import CartWidget from "./CartWidget";

export default function NavBar() {
  return (
    <nav className="nav">
      <Link to="/" className="nav-link" activeProps={{ className: "nav-link active" }} activeOptions={{ exact: true }}>Inicio</Link>
      <Link to="/productos" className="nav-link" activeProps={{ className: "nav-link active" }}>Servicios</Link>
      <Link to="/carrito" className="nav-link" activeProps={{ className: "nav-link active" }}>Carrito</Link>
      <CartWidget />
    </nav>
  );
}
