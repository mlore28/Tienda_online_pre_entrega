import { Link } from "@tanstack/react-router";
import NavBar from "./NavBar";

export default function Header() {
  return (
    <header className="header">
      <div className="container header-inner">
        <Link to="/" className="logo">BOSS<span>-IT</span></Link>
        <NavBar />
      </div>
    </header>
  );
}
