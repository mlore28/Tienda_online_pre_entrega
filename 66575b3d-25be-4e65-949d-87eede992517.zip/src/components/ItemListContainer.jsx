import { useEffect, useState } from "react";
import Item from "./Item";

export default function ItemListContainer() {
  const [productos, setProductos] = useState([]);
  const [cargando, setCargando] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    fetch("/productos.json")
      .then((res) => res.json())
      .then((data) => setProductos(data))
      .catch(() => setError("No se pudieron cargar los servicios."))
      .finally(() => setCargando(false));
  }, []);

  if (cargando) return <p className="muted">Cargando servicios...</p>;
  if (error) return <p className="muted">{error}</p>;

  return (
    <div className="grid">
      {productos.map((p) => (
        <Item key={p.id} {...p} />
      ))}
    </div>
  );
}
