import { Link } from "@tanstack/react-router";
import { useCart } from "../context/CartContext";

export default function CartWidget() {
  const { totalItems } = useCart();
  return (
    <Link to="/carrito" className="cart-widget" aria-label="Ver carrito">
      <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
        <circle cx="9" cy="21" r="1" /><circle cx="20" cy="21" r="1" />
        <path d="M1 1h4l2.7 13.4a2 2 0 0 0 2 1.6h9.7a2 2 0 0 0 2-1.6L23 6H6" />
      </svg>
      <span className="cart-badge">{totalItems}</span>
    </Link>
  );
}
