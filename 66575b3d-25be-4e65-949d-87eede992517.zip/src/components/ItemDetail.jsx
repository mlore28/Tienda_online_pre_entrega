import { useEffect, useState } from "react";
import { Link } from "@tanstack/react-router";
import { useCart } from "../context/CartContext";

export default function ItemDetail({ id }) {
  const [producto, setProducto] = useState(null);
  const [cargando, setCargando] = useState(true);
  const [agregado, setAgregado] = useState(false);
  const { addToCart } = useCart();

  useEffect(() => {
    fetch("/productos.json")
      .then((res) => res.json())
      .then((data) => setProducto(data.find((p) => String(p.id) === String(id)) || null))
      .finally(() => setCargando(false));
  }, [id]);

  if (cargando) return <p className="muted">Cargando...</p>;
  if (!producto) return <p className="muted">Servicio no encontrado. <Link to="/productos">Volver</Link></p>;

  return (
    <div className="detail">
      <div className="detail-icon">{producto.icono}</div>
      <div>
        <span className="tag">{producto.categoria}</span>
        <h1 className="h1">{producto.nombre}</h1>
        <p className="lead">{producto.descripcion}</p>
        <p className="price big">USD {producto.precio.toLocaleString("es-AR")} <span className="muted small">/ {producto.unidad}</span></p>
        <div className="row">
          <button className="btn" onClick={() => { addToCart(producto); setAgregado(true); }}>Agregar al carrito</button>
          <Link to="/productos" className="btn btn-outline">Volver</Link>
        </div>
        {agregado && <p className="ok">✓ Agregado al carrito</p>}
      </div>
    </div>
  );
}
