import { createFileRoute, Link } from "@tanstack/react-router";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "BOSS-IT — Staffing IT, Odoo y Transformación Digital" },
      { name: "description", content: "Contratá servicios de staffing IT, implementación Odoo y consultoría digital." },
      { property: "og:title", content: "BOSS-IT — Staffing IT, Odoo y Transformación Digital" },
      { property: "og:description", content: "Contratá servicios de staffing IT, implementación Odoo y consultoría digital." },
    ],
  }),
  component: Home,
});

function Home() {
  return (
    <section className="hero">
      <p className="eyebrow">Transformamos tu negocio con tecnología</p>
      <h1 className="hero-title">Talento IT y soluciones <em>Odoo</em> para crecer sin fricción.</h1>
      <p className="lead">Armá tu equipo, digitalizá tus procesos y elegí los servicios que tu empresa necesita.</p>
      <Link to="/productos" className="btn">Ver servicios</Link>
    </section>
  );
}
