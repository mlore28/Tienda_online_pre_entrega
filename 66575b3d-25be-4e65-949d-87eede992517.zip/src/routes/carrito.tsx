import { createFileRoute, Link } from "@tanstack/react-router";
import { useCart } from "../context/CartContext";

export const Route = createFileRoute("/carrito")({
  head: () => ({
    meta: [
      { title: "Carrito — BOSS-IT" },
      { name: "description", content: "Revisá los servicios agregados a tu carrito." },
      { property: "og:title", content: "Carrito — BOSS-IT" },
      { property: "og:description", content: "Revisá los servicios agregados a tu carrito." },
    ],
  }),
  component: Carrito,
});

type CartItem = { id: number; nombre: string; precio: number; cantidad: number; icono: string };

function Carrito() {
  const { cart, removeFromCart, clearCart, totalPrice } = useCart() as {
    cart: CartItem[]; removeFromCart: (id: number) => void; clearCart: () => void; totalPrice: number;
  };

  if (cart.length === 0) {
    return (
      <div className="empty">
        <h1 className="h1">Tu carrito está vacío</h1>
        <Link to="/productos" className="btn">Explorar servicios</Link>
      </div>
    );
  }

  return (
    <>
      <h1 className="h1">Tu carrito</h1>
      <ul className="cart-list">
        {cart.map((p) => (
          <li key={p.id} className="cart-row">
            <span className="cart-icon">{p.icono}</span>
            <span className="cart-name">{p.nombre}</span>
            <span className="muted">x{p.cantidad}</span>
            <span className="price">USD {(p.precio * p.cantidad).toLocaleString("es-AR")}</span>
            <button className="btn-link" onClick={() => removeFromCart(p.id)}>Quitar</button>
          </li>
        ))}
      </ul>
      <div className="cart-total">
        <button className="btn btn-outline" onClick={clearCart}>Vaciar</button>
        <p className="price big">Total: USD {totalPrice.toLocaleString("es-AR")}</p>
      </div>
    </>
  );
}
