import { createFileRoute } from "@tanstack/react-router";
import ItemListContainer from "../components/ItemListContainer";

export const Route = createFileRoute("/productos")({
  head: () => ({
    meta: [
      { title: "Servicios — BOSS-IT" },
      { name: "description", content: "Catálogo de servicios: staffing IT, Odoo, consultoría y desarrollo." },
      { property: "og:title", content: "Servicios — BOSS-IT" },
      { property: "og:description", content: "Catálogo de servicios: staffing IT, Odoo, consultoría y desarrollo." },
    ],
  }),
  component: () => (
    <>
      <h1 className="h1">Nuestros servicios</h1>
      <ItemListContainer />
    </>
  ),
});
