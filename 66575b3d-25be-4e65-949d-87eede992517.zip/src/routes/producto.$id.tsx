import { createFileRoute } from "@tanstack/react-router";
import ItemDetail from "../components/ItemDetail";

export const Route = createFileRoute("/producto/$id")({
  head: () => ({
    meta: [
      { title: "Detalle del servicio — BOSS-IT" },
      { name: "description", content: "Conocé el detalle y precio de este servicio de BOSS-IT." },
      { property: "og:title", content: "Detalle del servicio — BOSS-IT" },
      { property: "og:description", content: "Conocé el detalle y precio de este servicio de BOSS-IT." },
    ],
  }),
  component: Detalle,
});

function Detalle() {
  const { id } = Route.useParams();
  return <ItemDetail id={id} />;
}
